import { useEffect, useState } from 'react';
import { ArrowUpRight, Expand, X } from 'lucide-react';

interface EvidenceRecord {
  id: string;
  dateUtc: string;
  title: string;
  actors: string;
  imageSrc: string;
  alt: string;
  summary: string;
  lgpdIssue: string;
}

const EVIDENCE_RECORDS: EvidenceRecord[] = [
  {
    id: 'ev-aug-25',
    dateUtc: '25 de agosto de 2025 · 14h09–14h16 UTC',
    title: '01. Associação pública de nome civil em pedido de verificação',
    actors: 'Chronus · Edmond Dantès · Johannnnes89 · Teles',
    imageSrc: '/assets/aistudio/image_38d9f24c.png',
    alt: 'Captura de tela de discussão na Wikipédia em 25 de agosto de 2025 envolvendo Chronus, Edmond Dantès, Johannnnes89 e Teles.',
    summary:
      'No registro público de verificação, Chronus marca Johannnnes89, Teles e Conde Edmond Dantès vinculando uma conta ao nome civil completo ("Pedro Henrique Cardona Peres"). Mesmo após Edmond Dantès afirmar que limitações da ferramenta impediam a verificação da conta inativa desde março de 2025, Chronus insiste na associação direta com o usuário Wazzimagiygg em página aberta.',
    lgpdIssue:
      'Exposição de nome civil completo associado a perfis em log público indexável, sem consentimento ou verificação técnica conclusiva.',
  },
  {
    id: 'ev-aug-28',
    dateUtc: '28 de agosto de 2025 · 01h14 UTC',
    title: '02. Confirmação cruzada e vinculação de identidade civil',
    actors: 'Edmond Dantès (Verificador) · Contas citadas',
    imageSrc: '/assets/aistudio/image_f27bbf8d.png',
    alt: 'Captura de tela de resultado de verificação de 28 de agosto de 2025 assinado por Edmond Dantès.',
    summary:
      'Três dias depois, o verificador Edmond Dantès publica parecer de confirmação vinculando contas listadas diretamente ao nome civil Pedro Henrique Cardona Peres em registro público da Wikipédia lusófona, sem mecanismo independente de revisão externa ou anonimização do titular.',
    lgpdIssue:
      'Ausência de minimização de dados e de controle de retificação/exclusão previstos nos artigos 6º e 18 da LGPD.',
  },
  {
    id: 'ev-dec-23',
    dateUtc: '23–24 de dezembro de 2025 · 18h03–00h33 UTC',
    title: '03. Pedido em WP:NI e conclusão imediata por verificador',
    actors: 'Chronus · Edmond Dantès',
    imageSrc: '/assets/aistudio/image_d1a21d05.png',
    alt: 'Captura de tela de solicitação de verificação de 23 de dezembro de 2025 aberta por Chronus e confirmada por Edmond Dantès em 24 de dezembro de 2025.',
    summary:
      'Em 23 de dezembro de 2025, Chronus abre novo pedido citando solicitação aberta contra ele em WP:NI (Notificação de Incidentes), atribuindo a conta ao usuário Wazzimagiygg. Às 00h33min de 24 de dezembro, Edmond Dantès encerra a verificação como confirmada com outro perfil — ilustrando como os mesmos moderadores e verificadores acumulam denúncias, julgamentos e bloqueios dentro de um círculo fechado.',
    lgpdIssue:
      'Concentração de poder decisório sem auditoria externa e uso de ferramentas de verificação em disputas envolvendo o próprio solicitante.',
  },
];

export function DossierSection() {
  const [selectedRecord, setSelectedRecord] = useState<EvidenceRecord | null>(null);

  useEffect(() => {
    if (!selectedRecord) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedRecord(null);
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [selectedRecord]);

  return (
    <section id="dossie" className="border-t border-white/10 py-20">
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-3xl">
            <p className="text-xs font-medium text-[#FCA5A5]">
              Registros Documentais · Dossiê A Verdade
            </p>
            <h2 className="text-balance mt-3 font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Evidências de moderação centralizada, exposição civil e falhas de LGPD
            </h2>
            <p className="mt-4 text-base leading-relaxed text-slate-300">
              Abaixo estão os registros anexados sobre a atuação de Chronus e moderadores/verificadores envolvidos (Edmond Dantès, Johannnnes89 e Teles) em páginas de verificação da Wikipédia em português, que fundamentam a denúncia pública reunida no dossiê{' '}
              <span className="font-medium text-white">wazzimagiygg.com/averdade</span>.
            </p>
          </div>

          <a
            href="https://wazzimagiygg.com/averdade/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/[0.05] px-4 py-2.5 text-xs font-medium text-white transition-colors hover:bg-white/[0.1] whitespace-nowrap shrink-0"
          >
            Ler dossiê completo (A Verdade)
            <ArrowUpRight className="h-4 w-4" />
          </a>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {EVIDENCE_RECORDS.map((record) => (
            <article
              key={record.id}
              className="flex flex-col overflow-hidden rounded-xl border border-white/10 bg-[#12141A]"
            >
              <button
                type="button"
                onClick={() => setSelectedRecord(record)}
                aria-label={`Ampliar imagem: ${record.title}`}
                className="group relative aspect-video w-full overflow-hidden border-b border-white/10 bg-[#0A0B0E] text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3B82F6]"
              >
                <img
                  src={record.imageSrc}
                  alt={record.alt}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-contain bg-[#E8F5EC] p-1 transition-transform duration-300 group-hover:scale-[1.02]"
                />
                <span className="absolute right-3 bottom-3 inline-flex items-center gap-1.5 rounded-md bg-black/80 px-2.5 py-1 text-xs font-medium text-white">
                  <Expand className="h-3.5 w-3.5" />
                  Ampliar captura
                </span>
              </button>

              <div className="flex flex-1 flex-col justify-between p-6">
                <div>
                  <p className="font-mono-tabular text-xs text-slate-400">
                    {record.dateUtc}
                  </p>
                  <p className="mt-1 text-xs font-medium text-[#FCA5A5]">
                    {record.actors}
                  </p>
                  <h3 className="mt-2 font-display text-lg font-semibold leading-snug text-white">
                    {record.title}
                  </h3>
                  <p className="mt-3 text-sm leading-relaxed text-slate-300">
                    {record.summary}
                  </p>
                </div>

                <div className="mt-5 border-t border-white/10 pt-4">
                  <p className="text-xs font-medium text-[#60A5FA]">
                    Impacto sob a ótica da LGPD e governança
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-slate-400">
                    {record.lgpdIssue}
                  </p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Lightbox Modal for full-resolution inspection */}
      {selectedRecord && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={selectedRecord.title}
          onClick={() => setSelectedRecord(null)}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-2xl border border-white/15 bg-[#12141A] p-6"
          >
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono-tabular text-xs text-slate-400">
                  {selectedRecord.dateUtc} · {selectedRecord.actors}
                </p>
                <h3 className="mt-1 font-display text-xl font-semibold text-white">
                  {selectedRecord.title}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRecord(null)}
                aria-label="Fechar visualização"
                className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 text-slate-300 transition-colors hover:bg-white/10 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-4 overflow-hidden rounded-xl border border-white/10 bg-[#E8F5EC] p-2">
              <img
                src={selectedRecord.imageSrc}
                alt={selectedRecord.alt}
                referrerPolicy="no-referrer"
                className="mx-auto max-h-[55vh] w-auto object-contain"
              />
            </div>

            <p className="mt-4 text-sm leading-relaxed text-slate-200">
              {selectedRecord.summary}
            </p>
            <p className="mt-2 text-xs leading-relaxed text-[#FCA5A5]">
              {selectedRecord.lgpdIssue}
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
