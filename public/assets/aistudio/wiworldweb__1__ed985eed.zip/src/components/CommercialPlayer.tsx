import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Captions,
  Download,
  Maximize2,
  Mic,
  MicOff,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { formatTimecode, type CommercialScene } from '../data/commercialScenes';
import { CommercialAudioEngine } from '../utils/audioEngine';
import { renderCommercialFrame } from '../utils/canvasRenderer';

interface CommercialPlayerProps {
  scenes: CommercialScene[];
  activeSceneIndex: number;
  onActiveSceneChange: (index: number) => void;
  jumpRequest: { index: number; nonce: number } | null;
  exportTriggerNonce: number;
}

export function CommercialPlayer({
  scenes,
  onActiveSceneChange,
  jumpRequest,
  exportTriggerNonce,
}: CommercialPlayerProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stageContainerRef = useRef<HTMLDivElement | null>(null);
  const audioRef = useRef<CommercialAudioEngine | null>(null);
  const loadedImagesRef = useRef<Record<string, HTMLImageElement>>({});

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [playbackRate, setPlaybackRate] = useState<1 | 1.25>(1);
  const [isMuted, setIsMuted] = useState(false);
  const [narrationEnabled, setNarrationEnabled] = useState(false);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportMessage, setExportMessage] = useState<string | null>(null);

  const lastSpokenSceneIdRef = useRef<string | null>(null);
  const lastFrameTimeRef = useRef<number | null>(null);
  const rafRef = useRef<number | null>(null);
  const isExportingRef = useRef(false);

  const sceneOffsets = useMemo(() => {
    let acc = 0;
    return scenes.map((scene) => {
      const start = acc;
      acc += scene.durationSec;
      return { scene, start, end: acc };
    });
  }, [scenes]);

  const totalDuration = useMemo(
    () => scenes.reduce((sum, s) => sum + s.durationSec, 0),
    [scenes]
  );

  const currentSceneInfo = useMemo(() => {
    const clamped = Math.max(0, Math.min(totalDuration - 0.001, currentTime));
    const foundIdx = sceneOffsets.findIndex(
      (item) => clamped >= item.start && clamped < item.end
    );
    const idx = foundIdx === -1 ? Math.max(0, scenes.length - 1) : foundIdx;
    const item = sceneOffsets[idx];
    const localTime = clamped - item.start;
    const progress = item.scene.durationSec > 0 ? localTime / item.scene.durationSec : 0;
    return { idx, scene: item.scene, progress };
  }, [currentTime, sceneOffsets, scenes.length, totalDuration]);

  // Preload scene plate and documentary evidence images once
  useEffect(() => {
    const loadImg = (src: string) => {
      if (!loadedImagesRef.current[src]) {
        const img = new Image();
        img.src = src;
        loadedImagesRef.current[src] = img;
      }
    };

    scenes.forEach((s) => {
      if (s.imageSrc) loadImg(s.imageSrc);
      if (s.evidenceImages) {
        s.evidenceImages.forEach(loadImg);
      }
    });
  }, [scenes]);

  // Initialize audio engine
  useEffect(() => {
    audioRef.current = new CommercialAudioEngine();
    return () => {
      audioRef.current?.dispose();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Sync mute state
  useEffect(() => {
    audioRef.current?.setMuted(isMuted);
  }, [isMuted]);

  // Report active scene index up
  useEffect(() => {
    onActiveSceneChange(currentSceneInfo.idx);
  }, [currentSceneInfo.idx, onActiveSceneChange]);

  // Handle jump requests from storyboard
  useEffect(() => {
    if (!jumpRequest) return;
    const target = sceneOffsets[jumpRequest.index];
    if (!target) return;
    setCurrentTime(target.start);
    lastSpokenSceneIdRef.current = null;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(true);
    audioRef.current?.start();
  }, [jumpRequest, sceneOffsets]);

  // Handle narration per scene
  useEffect(() => {
    if (!isPlaying || !narrationEnabled || isExporting) {
      if ('speechSynthesis' in window && (!isPlaying || !narrationEnabled)) {
        window.speechSynthesis.cancel();
      }
      return;
    }

    const activeScene = currentSceneInfo.scene;
    if (lastSpokenSceneIdRef.current !== activeScene.id) {
      lastSpokenSceneIdRef.current = activeScene.id;
      audioRef.current?.triggerSceneCue(currentSceneInfo.idx);

      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(activeScene.narration);
        utterance.lang = 'pt-BR';
        utterance.rate = playbackRate === 1.25 ? 1.18 : 1.02;
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [
    isPlaying,
    narrationEnabled,
    isExporting,
    currentSceneInfo.scene,
    currentSceneInfo.idx,
    playbackRate,
  ]);

  // Scene chime when narration is off
  useEffect(() => {
    if (!isPlaying || narrationEnabled) return;
    if (lastSpokenSceneIdRef.current !== currentSceneInfo.scene.id) {
      lastSpokenSceneIdRef.current = currentSceneInfo.scene.id;
      audioRef.current?.triggerSceneCue(currentSceneInfo.idx);
    }
  }, [isPlaying, narrationEnabled, currentSceneInfo.scene.id, currentSceneInfo.idx]);

  // Main animation & rendering loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const drawCurrent = (timeSec: number) => {
      const clamped = Math.max(0, Math.min(totalDuration - 0.001, timeSec));
      const foundIdx = sceneOffsets.findIndex(
        (item) => clamped >= item.start && clamped < item.end
      );
      const idx = foundIdx === -1 ? Math.max(0, scenes.length - 1) : foundIdx;
      const item = sceneOffsets[idx];
      const progress =
        item.scene.durationSec > 0 ? (clamped - item.start) / item.scene.durationSec : 0;

      renderCommercialFrame({
        ctx,
        width: canvas.width,
        height: canvas.height,
        scene: item.scene,
        sceneProgress: progress,
        globalTime: timeSec,
        totalDuration,
        showSubtitles,
        loadedImages: loadedImagesRef.current,
      });
    };

    if (!isPlaying) {
      drawCurrent(currentTime);
      return;
    }

    lastFrameTimeRef.current = performance.now();

    const tick = (now: number) => {
      const prev = lastFrameTimeRef.current ?? now;
      const dt = ((now - prev) / 1000) * playbackRate;
      lastFrameTimeRef.current = now;

      setCurrentTime((prevTime) => {
        const next = prevTime + dt;
        if (next >= totalDuration) {
          if (isExportingRef.current) {
            return totalDuration;
          }
          setIsPlaying(false);
          audioRef.current?.stop();
          if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
          }
          return totalDuration;
        }
        drawCurrent(next);
        return next;
      });

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
    };
  }, [isPlaying, currentTime, totalDuration, sceneOffsets, scenes.length, showSubtitles, playbackRate]);

  const togglePlay = () => {
    if (isExporting) return;
    if (isPlaying) {
      setIsPlaying(false);
      audioRef.current?.stop();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } else {
      if (currentTime >= totalDuration - 0.05) {
        setCurrentTime(0);
        lastSpokenSceneIdRef.current = null;
      }
      setIsPlaying(true);
      audioRef.current?.start();
    }
  };

  const handleRestart = () => {
    if (isExporting) return;
    setCurrentTime(0);
    lastSpokenSceneIdRef.current = null;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsPlaying(true);
    audioRef.current?.start();
  };

  const handleScrub = (val: number) => {
    if (isExporting) return;
    setCurrentTime(val);
    lastSpokenSceneIdRef.current = null;
  };

  const handleFullscreen = () => {
    const el = stageContainerRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      void document.exitFullscreen();
    } else if (el.requestFullscreen) {
      void el.requestFullscreen();
    }
  };

  const handleExportVideo = async () => {
    if (isExporting) return;
    const canvas = canvasRef.current;
    if (!canvas || typeof MediaRecorder === 'undefined') {
      setExportMessage(
        'Seu navegador não suporta gravação via MediaRecorder. Utilize o player interativo acima.'
      );
      return;
    }

    setExportMessage(null);
    setIsExporting(true);
    isExportingRef.current = true;
    setExportProgress(0);
    setIsPlaying(false);
    audioRef.current?.stop();
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }

    try {
      const videoStream = canvas.captureStream(30);
      const audioStream = audioRef.current?.getStream();
      const tracks = [...videoStream.getVideoTracks()];
      if (audioStream) {
        tracks.push(...audioStream.getAudioTracks());
      }
      const combinedStream = new MediaStream(tracks);

      const mimeCandidates = [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp8,opus',
        'video/webm',
      ];
      const supportedMime = mimeCandidates.find((m) => MediaRecorder.isTypeSupported(m));
      const recorder = new MediaRecorder(
        combinedStream,
        supportedMime ? { mimeType: supportedMime, videoBitsPerSecond: 4_500_000 } : undefined
      );

      const chunks: BlobPart[] = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      const recordingFinished = new Promise<void>((resolve) => {
        recorder.onstop = () => resolve();
      });

      setCurrentTime(0);
      lastSpokenSceneIdRef.current = null;
      audioRef.current?.start();
      recorder.start(250);
      setIsPlaying(true);

      const exportStart = performance.now();
      const expectedMs = (totalDuration / playbackRate) * 1000;

      const progressTimer = window.setInterval(() => {
        const elapsed = performance.now() - exportStart;
        const pct = Math.min(99, Math.round((elapsed / expectedMs) * 100));
        setExportProgress(pct);
      }, 150);

      await new Promise<void>((resolve) => {
        const checkDone = window.setInterval(() => {
          const elapsed = performance.now() - exportStart;
          if (elapsed >= expectedMs + 150) {
            window.clearInterval(checkDone);
            resolve();
          }
        }, 100);
      });

      window.clearInterval(progressTimer);
      setExportProgress(100);
      setIsPlaying(false);
      audioRef.current?.stop();
      recorder.stop();
      await recordingFinished;

      const blob = new Blob(chunks, { type: supportedMime || 'video/webm' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = 'wiworldweb-comercial.webm';
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
      URL.revokeObjectURL(url);

      setExportMessage('Vídeo exportado em formato WebM com trilha sonora e legendas.');
    } catch {
      setExportMessage(
        'Não foi possível concluir a exportação automática neste navegador. Tente reproduzir em tela cheia.'
      );
    } finally {
      setIsExporting(false);
      isExportingRef.current = false;
    }
  };

  // Trigger export from external top-bar CTA button
  const prevExportNonceRef = useRef(exportTriggerNonce);
  useEffect(() => {
    if (exportTriggerNonce !== prevExportNonceRef.current) {
      prevExportNonceRef.current = exportTriggerNonce;
      void handleExportVideo();
    }
  });

  return (
    <div className="w-full">
      <div
        ref={stageContainerRef}
        className="relative overflow-hidden rounded-2xl border border-white/10 bg-[#090B10]"
      >
        {/* 16:9 Cinema Canvas */}
        <div className="relative aspect-video w-full bg-[#090B10]">
          <canvas
            ref={canvasRef}
            width={1280}
            height={720}
            onClick={togglePlay}
            className="h-full w-full cursor-pointer object-contain"
          />

          {/* Big Center Play Overlay when paused at start */}
          {!isPlaying && !isExporting && (
            <button
              type="button"
              onClick={togglePlay}
              aria-label="Reproduzir vídeo comercial WiWorldWeb"
              className="group absolute inset-0 flex flex-col items-center justify-center bg-black/35 transition-colors hover:bg-black/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#3B82F6]"
            >
              <span className="flex h-16 w-16 items-center justify-center rounded-full bg-[#2563EB] text-white shadow-lg transition-transform duration-200 group-hover:scale-105">
                <Play className="ml-1 h-7 w-7 fill-current" />
              </span>
              <span className="mt-4 text-sm font-medium text-slate-200">
                {currentTime > 0.5 && currentTime < totalDuration - 0.5
                  ? 'Continuar comercial'
                  : 'Assistir comercial WiWorldWeb'}
              </span>
            </button>
          )}

          {/* Export progress scrim */}
          {isExporting && (
            <div className="absolute inset-x-0 bottom-0 bg-black/80 px-6 py-4 backdrop-blur-sm">
              <div className="flex items-center justify-between text-xs font-medium text-slate-200">
                <span>Renderizando vídeo comercial WebM em tempo real…</span>
                <span className="font-mono-tabular">{exportProgress}%</span>
              </div>
              <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full bg-[#2563EB] transition-all duration-150"
                  style={{ width: `${exportProgress}%` }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Transport & Studio Controls Bar */}
        <div className="border-t border-white/10 bg-[#12141A] px-4 py-3 sm:px-6">
          {/* Scene Markers & Scrubber */}
          <div className="mb-3 flex flex-col gap-2">
            <input
              type="range"
              min={0}
              max={totalDuration}
              step={0.1}
              value={currentTime}
              disabled={isExporting}
              onChange={(e) => handleScrub(Number(e.target.value))}
              aria-label="Linha do tempo do comercial"
              className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-[#2563EB] disabled:cursor-not-allowed"
            />
            <div className="grid grid-cols-3 gap-1.5 sm:grid-cols-6">
              {sceneOffsets.map(({ scene, start }, idx) => {
                const isActive = idx === currentSceneInfo.idx;
                return (
                  <button
                    key={scene.id}
                    type="button"
                    disabled={isExporting}
                    onClick={() => handleScrub(start)}
                    className={`truncate rounded-md px-2.5 py-1.5 text-left text-xs transition-colors whitespace-nowrap ${
                      isActive
                        ? 'bg-[#2563EB]/20 font-medium text-white border border-[#3B82F6]/40'
                        : 'bg-white/[0.03] text-slate-400 border border-transparent hover:bg-white/[0.06] hover:text-slate-200'
                    }`}
                    title={`${scene.number}. ${scene.chapter}`}
                  >
                    <span className="font-mono-tabular mr-1.5 text-[11px] opacity-75">
                      {scene.number}
                    </span>
                    {scene.chapter}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Primary Transport Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={togglePlay}
                disabled={isExporting}
                className="inline-flex items-center gap-2 rounded-lg bg-[#2563EB] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#1D4ED8] disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                {isPlaying ? (
                  <>
                    <Pause className="h-3.5 w-3.5" />
                    Pausar
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5 fill-current" />
                    Reproduzir
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleRestart}
                disabled={isExporting}
                aria-label="Reiniciar vídeo"
                className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-slate-300 transition-colors hover:bg-white/5 hover:text-white disabled:opacity-50"
              >
                <RotateCcw className="h-3.5 w-3.5" />
              </button>

              <span className="font-mono-tabular ml-2 text-xs text-slate-400 whitespace-nowrap">
                {formatTimecode(currentTime)} / {formatTimecode(totalDuration)}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setIsMuted((m) => !m)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white whitespace-nowrap shrink-0"
              >
                {isMuted ? (
                  <>
                    <VolumeX className="h-3.5 w-3.5 text-slate-400" />
                    Sem trilha
                  </>
                ) : (
                  <>
                    <Volume2 className="h-3.5 w-3.5 text-[#3B82F6]" />
                    Trilha ativa
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setNarrationEnabled((n) => !n)}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  narrationEnabled
                    ? 'border-[#3B82F6]/50 bg-[#2563EB]/15 text-white'
                    : 'border-white/10 text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                {narrationEnabled ? (
                  <>
                    <Mic className="h-3.5 w-3.5 text-[#3B82F6]" />
                    Narração pt-BR
                  </>
                ) : (
                  <>
                    <MicOff className="h-3.5 w-3.5 text-slate-400" />
                    Narração desligada
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setShowSubtitles((s) => !s)}
                className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  showSubtitles
                    ? 'border-[#3B82F6]/50 bg-[#2563EB]/15 text-white'
                    : 'border-white/10 text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Captions className="h-3.5 w-3.5" />
                Legendas
              </button>

              <button
                type="button"
                onClick={() => setPlaybackRate((r) => (r === 1 ? 1.25 : 1))}
                className="font-mono-tabular inline-flex items-center rounded-lg border border-white/10 px-2.5 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white whitespace-nowrap shrink-0"
              >
                {playbackRate}x
              </button>

              <button
                type="button"
                onClick={() => void handleExportVideo()}
                disabled={isExporting}
                className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/[0.06] px-3.5 py-1.5 text-xs font-medium text-white transition-colors hover:bg-white/[0.12] disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Download className="h-3.5 w-3.5" />
                {isExporting ? 'Exportando…' : 'Baixar WebM'}
              </button>

              <button
                type="button"
                onClick={handleFullscreen}
                aria-label="Tela cheia"
                className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                <Maximize2 className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {exportMessage && (
            <p className="mt-3 text-xs text-slate-300">{exportMessage}</p>
          )}
        </div>
      </div>
    </div>
  );
}
