import { useState } from 'react';
import decentralizedImg from '../assets/images/wiworld_decentralized_network_1794754775241.jpg';
import lgpdImg from '../assets/images/wiworld_lgpd_privacy_1794754776155.jpg';
import realtimeImg from '../assets/images/wiworld_realtime_collab_1794754777290.jpg';

interface VisualCardProps {
  imageSrc: string;
  alt: string;
  kicker: string;
  title: string;
  description: string;
  spanClass?: string;
}

function VisualPillarCard({
  imageSrc,
  alt,
  kicker,
  title,
  description,
  spanClass = '',
}: VisualCardProps) {
  const [imgError, setImgError] = useState(false);

  return (
    <article
      className={`group overflow-hidden rounded-xl border border-white/10 bg-[#12141A] flex flex-col ${spanClass}`}
    >
      <div className="relative aspect-video w-full overflow-hidden bg-[#181B23]">
        {!imgError ? (
          <img
            src={imageSrc}
            alt={alt}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#12141A] to-[#1E293B] p-6 text-center">
            <span className="font-display text-lg font-semibold text-slate-300">{title}</span>
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col justify-between p-6">
        <div>
          <p className="text-xs font-medium text-[#60A5FA]">{kicker}</p>
          <h3 className="mt-2 font-display text-xl font-semibold tracking-tight text-white">
            {title}
          </h3>
          <p className="mt-2.5 text-sm leading-relaxed text-slate-300">{description}</p>
        </div>
      </div>
    </article>
  );
}

const COMPARISON_ROWS = [
  {
    axis: '01. Governança e Moderação',
    wikipedia:
      'Concentração de privilégios administrativos e de verificação (CheckUser) em círculos internos — como nos registros de 2025 envolvendo Chronus, Edmond Dantès, Johannnnes89 e Teles em páginas de verificação e WP:NI — onde denúncias, vinculações de nome civil e confirmações ocorrem sem auditoria externa independente.',
    wiworldweb:
      'Governança federada e transparente com trilhas de auditoria imutáveis, revisão coletiva sem bloqueios arbitrários de página e autonomia de instâncias comunitárias.',
  },
  {
    axis: '02. Privacidade e LGPD (Lei nº 13.709/2018)',
    wikipedia:
      'Registros públicos tradicionais exibem endereços IP de editores não autenticados e mantêm histórico centralizado sob políticas externas à jurisdição brasileira.',
    wiworldweb:
      'Arquitetura Privacy by Design alinhada à LGPD: ocultação de IP, minimização de coleta de dados pessoais, consentimento explícito e direitos do titular (Art. 18) integrados ao fluxo.',
  },
  {
    axis: '03. Colaboração em Tempo Real',
    wikipedia:
      'Edição por envio sequencial de formulários sujeita a conflitos manuais de versão, guerras de reversão e travamentos administrativos de artigos.',
    wiworldweb:
      'Edição simultânea em tempo real com resolução automática de alterações (CRDT), presença visível de coautores e histórico verificável sem interrupções.',
  },
  {
    axis: '04. Infraestrutura e Soberania',
    wikipedia:
      'Plataforma hospedada em estrutura centralizada única; comunidades dependem de decisões globais de fundação e políticas fechadas de software.',
    wiworldweb:
      'Rede descentralizada de código aberto (WazzimaGiygg/Wiki-alternative): qualquer organização, universidade ou coletivo pode operar seu próprio nó com interoperabilidade.',
  },
];

export function ComparisonSection() {
  return (
    <section id="comparativo" className="border-t border-white/10 py-20">
      <div className="mx-auto max-w-6xl px-6">
        <div className="max-w-2xl">
          <p className="text-xs font-medium text-[#60A5FA]">Arquitetura e Governança</p>
          <h2 className="text-balance mt-3 font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
            Por que migrar de um modelo centralizado para o WiWorldWeb
          </h2>
          <p className="mt-4 text-base leading-relaxed text-slate-300">
            O comercial contrasta quatro falhas estruturais do modelo enciclopédico tradicional com os pilares técnicos e jurídicos do projeto WiWorldWeb.
          </p>
        </div>

        {/* Asymmetric 3-card visual bento */}
        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-3">
          <VisualPillarCard
            imageSrc={decentralizedImg}
            alt="Representação arquitetônica da rede descentralizada do WiWorldWeb"
            kicker="Descentralização · Sem ponto único de falha"
            title="Rede federada e resistente a censura"
            description="Cada instância mantém cópia íntegra dos artigos e revisões. Bloqueios unilaterais em um servidor não apagam o trabalho da comunidade."
          />
          <VisualPillarCard
            imageSrc={lgpdImg}
            alt="Cofre translúcido representando proteção de dados e conformidade com a LGPD"
            kicker="Privacidade · Lei nº 13.709/2018"
            title="Conformidade LGPD desde o núcleo"
            description="Proteção de identidade contra doxxing e exposição de IP, consentimento granular e portabilidade direta conforme os princípios da LGPD."
          />
          <VisualPillarCard
            imageSrc={realtimeImg}
            alt="Mesa editorial representando colaboração em tempo real entre autores"
            kicker="Tempo Real · Fluxo contínuo"
            title="Edição simultânea sem guerras de reversão"
            description="Autores colaboram no mesmo verbete ao vivo com mesclagem determinística e histórico auditável para cada contribuição."
          />
        </div>

        {/* Detailed Comparison Table */}
        <div className="mt-14 overflow-hidden rounded-xl border border-white/10 bg-[#12141A]">
          <div className="grid grid-cols-1 border-b border-white/10 bg-white/[0.02] px-6 py-4 text-xs font-medium text-slate-400 md:grid-cols-12 md:gap-6">
            <div className="md:col-span-3">Eixo Comparativo</div>
            <div className="mt-1 md:col-span-4 md:mt-0">Wikipédia Tradicional</div>
            <div className="mt-1 text-[#60A5FA] md:col-span-5 md:mt-0">
              WiWorldWeb (Wiki-Alternative)
            </div>
          </div>

          <div className="divide-y divide-white/10">
            {COMPARISON_ROWS.map((row) => (
              <div
                key={row.axis}
                className="grid grid-cols-1 gap-4 px-6 py-6 md:grid-cols-12 md:gap-6"
              >
                <div className="font-display text-base font-semibold text-white md:col-span-3">
                  {row.axis}
                </div>
                <div className="text-sm leading-relaxed text-slate-400 md:col-span-4">
                  {row.wikipedia}
                </div>
                <div className="text-sm leading-relaxed text-slate-200 md:col-span-5">
                  {row.wiworldweb}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
