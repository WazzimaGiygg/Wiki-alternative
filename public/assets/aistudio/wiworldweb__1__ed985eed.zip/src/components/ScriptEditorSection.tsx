import { Download, Play, RotateCcw } from 'lucide-react';
import type { CommercialScene } from '../data/commercialScenes';

interface ScriptEditorSectionProps {
  scenes: CommercialScene[];
  activeSceneIndex: number;
  onUpdateScene: (index: number, patch: Partial<CommercialScene>) => void;
  onJumpToScene: (index: number) => void;
  onResetScenes: () => void;
}

export function ScriptEditorSection({
  scenes,
  activeSceneIndex,
  onUpdateScene,
  onJumpToScene,
  onResetScenes,
}: ScriptEditorSectionProps) {
  const totalSeconds = scenes.reduce((sum, s) => sum + s.durationSec, 0);

  const handleDownloadScript = () => {
    const content = scenes
      .map(
        (s) =>
          `[${s.number}] ${s.chapter} (${s.durationSec}s) — ${s.topic}\nTítulo na tela: ${s.headline}\nSubtítulo: ${s.subheadline}\nLocução / Legenda: ${s.narration}\n`
      )
      .join('\n----------------------------------------\n\n');

    const header = `ROTEIRO COMERCIAL — WIWORLDWEB\nRepositório: https://github.com/WazzimaGiygg/Wiki-alternative\nDuração total: ${totalSeconds}s\n\n========================================\n\n`;
    const blob = new Blob([header + content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = 'roteiro-comercial-wiworldweb.txt';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  };

  return (
    <section id="roteiro" className="border-t border-white/10 py-20">
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex flex-col justify-between gap-6 sm:flex-row sm:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-[#60A5FA]">
              Estúdio de Roteiro · {scenes.length} cenas ·{' '}
              <span className="font-mono-tabular">{totalSeconds}s</span> no total
            </p>
            <h2 className="text-balance mt-3 font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Personalize as cenas e a locução em tempo real
            </h2>
            <p className="mt-3 text-base leading-relaxed text-slate-300">
              Qualquer alteração feita abaixo atualiza imediatamente os quadros do vídeo, as legendas e a gravação WebM.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onResetScenes}
              className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-4 py-2 text-xs font-medium text-slate-300 transition-colors hover:bg-white/5 hover:text-white whitespace-nowrap"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Restaurar original
            </button>
            <button
              type="button"
              onClick={handleDownloadScript}
              className="inline-flex items-center gap-2 rounded-lg bg-[#2563EB] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#1D4ED8] whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              Baixar roteiro (.txt)
            </button>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-6 lg:grid-cols-2">
          {scenes.map((scene, index) => {
            const isActive = index === activeSceneIndex;
            return (
              <div
                key={scene.id}
                className={`rounded-xl border p-6 transition-colors ${
                  isActive
                    ? 'border-[#3B82F6]/60 bg-[#151A26]'
                    : 'border-white/10 bg-[#12141A]'
                }`}
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="font-mono-tabular font-medium text-[#60A5FA]">
                        Cena {scene.number}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate">{scene.topic}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono-tabular">{scene.durationSec}s</span>
                    </div>
                    <h3 className="mt-1 truncate font-display text-lg font-semibold text-white">
                      {scene.chapter}
                    </h3>
                  </div>

                  <button
                    type="button"
                    onClick={() => onJumpToScene(index)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:bg-[#2563EB] hover:border-[#2563EB] hover:text-white whitespace-nowrap shrink-0"
                  >
                    <Play className="h-3 w-3 fill-current" />
                    Pré-visualizar
                  </button>
                </div>

                <div className="mt-5 space-y-4">
                  <div>
                    <label
                      htmlFor={`headline-${scene.id}`}
                      className="block text-xs font-medium text-slate-400"
                    >
                      Título principal na tela
                    </label>
                    <input
                      id={`headline-${scene.id}`}
                      type="text"
                      value={scene.headline}
                      onChange={(e) => onUpdateScene(index, { headline: e.target.value })}
                      className="mt-1.5 w-full rounded-lg border border-white/10 bg-[#0A0B0E] px-3.5 py-2 text-sm text-white focus:border-[#3B82F6] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor={`sub-${scene.id}`}
                      className="block text-xs font-medium text-slate-400"
                    >
                      Texto de apoio
                    </label>
                    <textarea
                      id={`sub-${scene.id}`}
                      rows={2}
                      value={scene.subheadline}
                      onChange={(e) => onUpdateScene(index, { subheadline: e.target.value })}
                      className="mt-1.5 w-full resize-none rounded-lg border border-white/10 bg-[#0A0B0E] px-3.5 py-2 text-sm text-slate-200 focus:border-[#3B82F6] focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
                    <div className="sm:col-span-3">
                      <label
                        htmlFor={`narration-${scene.id}`}
                        className="block text-xs font-medium text-slate-400"
                      >
                        Locução e legenda (pt-BR)
                      </label>
                      <textarea
                        id={`narration-${scene.id}`}
                        rows={2}
                        value={scene.narration}
                        onChange={(e) => onUpdateScene(index, { narration: e.target.value })}
                        className="mt-1.5 w-full resize-none rounded-lg border border-white/10 bg-[#0A0B0E] px-3.5 py-2 text-sm text-slate-200 focus:border-[#3B82F6] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor={`dur-${scene.id}`}
                        className="block text-xs font-medium text-slate-400"
                      >
                        Duração (s)
                      </label>
                      <input
                        id={`dur-${scene.id}`}
                        type="number"
                        min={4}
                        max={30}
                        value={scene.durationSec}
                        onChange={(e) => {
                          const parsed = Number(e.target.value);
                          if (!Number.isNaN(parsed)) {
                            onUpdateScene(index, {
                              durationSec: Math.max(4, Math.min(30, parsed)),
                            });
                          }
                        }}
                        className="font-mono-tabular mt-1.5 w-full rounded-lg border border-white/10 bg-[#0A0B0E] px-3.5 py-2 text-sm text-white focus:border-[#3B82F6] focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
