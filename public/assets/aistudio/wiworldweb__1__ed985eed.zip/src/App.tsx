/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import heroBannerImg from './assets/images/hero_decentralized_banner_1794768375168.jpg';
import { CommercialPlayer } from './components/CommercialPlayer';
import { ComparisonSection } from './components/ComparisonSection';
import { DossierSection } from './components/DossierSection';
import { ScriptEditorSection } from './components/ScriptEditorSection';
import {
  DEFAULT_COMMERCIAL_SCENES,
  type CommercialScene,
} from './data/commercialScenes';

export default function App() {
  const [scenes, setScenes] = useState<CommercialScene[]>(DEFAULT_COMMERCIAL_SCENES);
  const [activeSceneIndex, setActiveSceneIndex] = useState(0);
  const [jumpRequest, setJumpRequest] = useState<{ index: number; nonce: number } | null>(
    null
  );
  const [exportTriggerNonce, setExportTriggerNonce] = useState(0);
  const [heroBannerError, setHeroBannerError] = useState(false);

  const handleUpdateScene = useCallback(
    (index: number, patch: Partial<CommercialScene>) => {
      setScenes((prev) =>
        prev.map((scene, idx) => (idx === index ? { ...scene, ...patch } : scene))
      );
    },
    []
  );

  const handleJumpToScene = useCallback((index: number) => {
    setJumpRequest({ index, nonce: Date.now() });
    const playerEl = document.getElementById('comercial');
    if (playerEl) {
      playerEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, []);

  const handleResetScenes = useCallback(() => {
    setScenes(DEFAULT_COMMERCIAL_SCENES);
  }, []);

  const handleTopBarExport = useCallback(() => {
    const playerEl = document.getElementById('comercial');
    if (playerEl) {
      playerEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setExportTriggerNonce((n) => n + 1);
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0B0E] text-[#F1F5F9]">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#0A0B0E]/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-6 py-4">
          {/* Zone 1: Single text element wordmark */}
          <a
            href="#comercial"
            className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            WiWorldWeb
          </a>

          {/* Zone 2: 4 concise single-line nav links */}
          <nav className="hidden items-center gap-7 text-sm font-medium text-slate-300 md:flex">
            <a
              href="#comercial"
              className="transition-colors hover:text-white hover:underline hover:underline-offset-8 whitespace-nowrap shrink-0"
            >
              Comercial
            </a>
            <a
              href="#comparativo"
              className="transition-colors hover:text-white hover:underline hover:underline-offset-8 whitespace-nowrap shrink-0"
            >
              Comparativo
            </a>
            <a
              href="#dossie"
              className="transition-colors hover:text-white hover:underline hover:underline-offset-8 whitespace-nowrap shrink-0"
            >
              Dossiê
            </a>
            <a
              href="#roteiro"
              className="transition-colors hover:text-white hover:underline hover:underline-offset-8 whitespace-nowrap shrink-0"
            >
              Roteiro
            </a>
          </nav>

          {/* Zone 3: 1 primary action */}
          <button
            type="button"
            onClick={handleTopBarExport}
            className="rounded-lg bg-[#2563EB] px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-[#1D4ED8] whitespace-nowrap shrink-0"
          >
            Exportar Vídeo
          </button>
        </div>
      </header>

      <main>
        {/* Top Architectural Hero Banner */}
        <section className="relative overflow-hidden border-b border-white/10 bg-[#0A0B0E]">
          {!heroBannerError ? (
            <img
              src={heroBannerImg}
              alt="Rede global futurista e descentralizada de conhecimento do projeto WiWorldWeb"
              referrerPolicy="no-referrer"
              onError={() => setHeroBannerError(true)}
              className="absolute inset-0 h-full w-full object-cover object-center"
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-[#0A0B0E] via-[#111827] to-[#1E3A8A]/30" />
          )}

          {/* Measured directional scrim for >= 4.5:1 text contrast */}
          <div
            aria-hidden="true"
            className="absolute inset-0 bg-gradient-to-r from-[#0A0B0E]/95 via-[#0A0B0E]/75 to-[#0A0B0E]/20"
          />
          <div
            aria-hidden="true"
            className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#0A0B0E] to-transparent"
          />

          <div className="relative mx-auto max-w-6xl px-6 py-16 sm:py-24 lg:py-28">
            <div className="max-w-2xl">
              <p className="text-xs font-medium text-[#60A5FA]">
                Projeto WiWorldWeb · Rede Descentralizada · Código Aberto
              </p>
              <h1 className="text-balance mt-3 font-display text-4xl font-semibold tracking-tight text-white sm:text-5xl lg:text-6xl">
                Conhecimento livre com descentralização, LGPD e colaboração em tempo real.
              </h1>
              <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-200">
                Uma arquitetura distribuída e transparente contra bloqueios arbitrários e exposição de dados civis. Assista ao vídeo comercial, analise os registros do dossiê e exporte o filme em WebM.
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-4">
                <a
                  href="#comercial"
                  className="rounded-lg bg-[#2563EB] px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-[#1D4ED8] whitespace-nowrap"
                >
                  Assistir ao comercial
                </a>
                <a
                  href="#dossie"
                  className="rounded-lg border border-white/15 bg-[#0A0B0E]/70 px-5 py-2.5 text-sm font-medium text-slate-200 backdrop-blur-sm transition-colors hover:bg-white/10 hover:text-white whitespace-nowrap"
                >
                  Ver registros e dossiê
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Dominant 16:9 Commercial Video Player */}
        <section id="comercial" className="py-12 sm:py-16">
          <div className="mx-auto max-w-6xl px-6">
            <div className="mb-6 flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
              <div>
                <p className="text-xs font-medium text-[#60A5FA]">
                  Player Interativo · 16:9 HD
                </p>
                <h2 className="mt-1 font-display text-2xl font-semibold tracking-tight text-white">
                  Filme Comercial WiWorldWeb
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                Clique no vídeo ou selecione qualquer cena abaixo para iniciar a reprodução.
              </p>
            </div>

            <CommercialPlayer
              scenes={scenes}
              activeSceneIndex={activeSceneIndex}
              onActiveSceneChange={setActiveSceneIndex}
              jumpRequest={jumpRequest}
              exportTriggerNonce={exportTriggerNonce}
            />
          </div>
        </section>

        {/* Proof & Technical/Governance Comparison */}
        <ComparisonSection />

        {/* Documentary Evidence & Dossier */}
        <DossierSection />

        {/* Interactive Script & Scene Customizer */}
        <ScriptEditorSection
          scenes={scenes}
          activeSceneIndex={activeSceneIndex}
          onUpdateScene={handleUpdateScene}
          onJumpToScene={handleJumpToScene}
          onResetScenes={handleResetScenes}
        />

        {/* Open-Source Repository & LGPD Manifesto */}
        <section id="repositorio" className="border-t border-white/10 py-20">
          <div className="mx-auto max-w-6xl px-6">
            <div className="rounded-2xl border border-white/10 bg-[#12141A] p-8 sm:p-12">
              <div className="grid grid-cols-1 items-center gap-8 lg:grid-cols-12">
                <div className="lg:col-span-8">
                  <p className="text-xs font-medium text-[#60A5FA]">
                    Código Aberto · Wiki-Alternative
                  </p>
                  <h2 className="text-balance mt-3 font-display text-3xl font-semibold tracking-tight text-white">
                    Audite o código, hospede um nó independente e proteja os dados dos colaboradores.
                  </h2>
                  <p className="mt-4 text-base leading-relaxed text-slate-300">
                    O repositório oficial reúne a base técnica da alternativa descentralizada à Wikipédia, com foco em transparência algorítmica, conformidade com a Lei Geral de Proteção de Dados (LGPD) e edição simultânea sem gargalos administrativos centralizados.
                  </p>
                </div>

                <div className="flex flex-col gap-3 lg:col-span-4 lg:items-end">
                  <a
                    href="https://github.com/WazzimaGiygg/Wiki-alternative"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#2563EB] px-5 py-3 text-sm font-medium text-white transition-colors hover:bg-[#1D4ED8] whitespace-nowrap"
                  >
                    Acessar GitHub do Projeto
                    <ArrowUpRight className="h-4 w-4" />
                  </a>
                  <a
                    href="https://wazzimagiygg.com/averdade/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 rounded-lg border border-white/15 bg-white/[0.04] px-5 py-2.5 text-xs font-medium text-slate-200 transition-colors hover:bg-white/[0.09] whitespace-nowrap"
                  >
                    Dossiê A Verdade (wazzimagiygg.com/averdade)
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </a>
                  <span className="font-mono-tabular text-xs text-slate-400">
                    github.com/WazzimaGiygg/Wiki-alternative
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-white/10 py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-4 px-6 text-xs text-slate-400 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <span className="font-display text-sm font-semibold text-white">WiWorldWeb</span>
            <span aria-hidden="true">·</span>
            <span>Alternativa descentralizada para conhecimento livre e LGPD</span>
          </div>
          <div className="flex items-center gap-6">
            <a href="#comercial" className="hover:text-white transition-colors">
              Comercial
            </a>
            <a href="#comparativo" className="hover:text-white transition-colors">
              Comparativo
            </a>
            <a href="#dossie" className="hover:text-white transition-colors">
              Dossiê
            </a>
            <a href="#roteiro" className="hover:text-white transition-colors">
              Roteiro
            </a>
            <a
              href="https://github.com/WazzimaGiygg/Wiki-alternative"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white transition-colors"
            >
              GitHub
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
