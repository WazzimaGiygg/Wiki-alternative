export class CommercialAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private monitorGain: GainNode | null = null;
  private streamDest: MediaStreamAudioDestinationNode | null = null;
  private stepInterval: number | null = null;
  private isPlaying = false;
  private isMuted = false;
  private currentStep = 0;

  private ensureContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.28;

      this.monitorGain = this.ctx.createGain();
      this.monitorGain.gain.value = this.isMuted ? 0 : 1;

      this.streamDest = this.ctx.createMediaStreamDestination();

      this.masterGain.connect(this.monitorGain);
      this.monitorGain.connect(this.ctx.destination);
      this.masterGain.connect(this.streamDest);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  public getStream(): MediaStream | null {
    this.ensureContext();
    return this.streamDest?.stream ?? null;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (this.monitorGain && this.ctx) {
      this.monitorGain.gain.setTargetAtTime(muted ? 0 : 1, this.ctx.currentTime, 0.06);
    }
  }

  public start(): void {
    const ctx = this.ensureContext();
    if (this.isPlaying) return;
    this.isPlaying = true;
    this.currentStep = 0;

    // Gentle procedural ambient pulse synchronized across scenes
    const scaleFreqs = [130.81, 155.56, 174.61, 196.0, 233.08, 261.63]; // C minor pentatonic
    const padChords = [
      [130.81, 196.0, 233.08, 311.13], // Cm7
      [116.54, 174.61, 207.65, 261.63], // Bb6/9
      [103.83, 155.56, 196.0, 233.08], // Abmaj9
      [98.0, 146.83, 196.0, 233.08], // Gm7
    ];

    const triggerTick = () => {
      if (!this.isPlaying || !this.ctx || !this.masterGain) return;
      const now = ctx.currentTime;

      // Every 8 steps (4 seconds), trigger a warm atmospheric pad chord
      if (this.currentStep % 8 === 0) {
        const chordIndex = Math.floor(this.currentStep / 8) % padChords.length;
        const chord = padChords[chordIndex];
        chord.forEach((freq) => {
          this.playPadVoice(freq, now, 3.8, 0.07);
        });
      }

      // Subtle documentary pulse arpeggio on alternating steps
      if (this.currentStep % 2 === 0) {
        const note = scaleFreqs[(this.currentStep / 2) % scaleFreqs.length] * 2;
        this.playPluck(note, now, 0.45, 0.045);
      }

      // Soft low sub beat every 4 steps
      if (this.currentStep % 4 === 0) {
        this.playSubPulse(65.41, now, 0.35, 0.14);
      }

      this.currentStep += 1;
    };

    triggerTick();
    this.stepInterval = window.setInterval(triggerTick, 500);
  }

  public stop(): void {
    this.isPlaying = false;
    if (this.stepInterval !== null) {
      window.clearInterval(this.stepInterval);
      this.stepInterval = null;
    }
  }

  public triggerSceneCue(accentIndex: number): void {
    if (!this.isPlaying) return;
    const ctx = this.ensureContext();
    const now = ctx.currentTime;
    const baseFreqs = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25];
    const freq = baseFreqs[accentIndex % baseFreqs.length];
    this.playPluck(freq, now, 0.7, 0.08);
    this.playPluck(freq * 1.5, now + 0.08, 0.65, 0.05);
  }

  private playPadVoice(freq: number, startTime: number, duration: number, volume: number): void {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, startTime);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(680, startTime);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.exponentialRampToValueAtTime(volume, startTime + 0.8);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.05);
  }

  private playPluck(freq: number, startTime: number, duration: number, volume: number): void {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(volume, startTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.05);
  }

  private playSubPulse(freq: number, startTime: number, duration: number, volume: number): void {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, startTime);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.72, startTime + duration);

    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.linearRampToValueAtTime(volume, startTime + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(startTime);
    osc.stop(startTime + duration + 0.05);
  }

  public dispose(): void {
    this.stop();
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
    }
  }
}
