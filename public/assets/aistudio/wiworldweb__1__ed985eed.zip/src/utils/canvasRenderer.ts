import type { CommercialScene } from '../data/commercialScenes';

export interface RenderFrameOptions {
  ctx: CanvasRenderingContext2D;
  width: number;
  height: number;
  scene: CommercialScene;
  sceneProgress: number; // 0..1 within current scene
  globalTime: number; // total elapsed seconds
  totalDuration: number;
  showSubtitles: boolean;
  loadedImages: Record<string, HTMLImageElement>;
}

function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - Math.max(0, Math.min(1, t)), 3);
}

function wrapTextLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxLines = 4
): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let current = '';

  for (const word of words) {
    const testLine = current ? `${current} ${word}` : word;
    if (ctx.measureText(testLine).width <= maxWidth) {
      current = testLine;
    } else {
      if (current) lines.push(current);
      current = word;
      if (lines.length >= maxLines - 1) break;
    }
  }
  if (current) lines.push(current);
  return lines;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
}

export function renderCommercialFrame({
  ctx,
  width,
  height,
  scene,
  sceneProgress,
  globalTime,
  totalDuration,
  showSubtitles,
  loadedImages,
}: RenderFrameOptions): void {
  const enter = easeOutCubic(Math.min(1, sceneProgress / 0.16));
  const exit = sceneProgress > 0.9 ? 1 - (sceneProgress - 0.9) / 0.1 : 1;
  const opacity = Math.max(0, Math.min(1, enter * exit));

  // 1. Base Obsidian Canvas
  ctx.fillStyle = '#090B10';
  ctx.fillRect(0, 0, width, height);

  // 2. Optional Background Image Plate with slow Ken Burns motion & measured dark scrim
  if (scene.imageSrc && loadedImages[scene.imageSrc]) {
    const img = loadedImages[scene.imageSrc];
    if (img.complete && img.naturalWidth > 0) {
      ctx.save();
      const scale = 1.04 + sceneProgress * 0.06;
      const drawW = width * scale;
      const drawH = height * scale;
      const offsetX = (width - drawW) * 0.5;
      const offsetY = (height - drawH) * 0.5;
      ctx.globalAlpha = 0.42 * opacity;
      ctx.drawImage(img, offsetX, offsetY, drawW, drawH);
      ctx.restore();

      // Measured editorial gradient scrim for guaranteed legibility
      const grad = ctx.createLinearGradient(0, 0, width, height);
      grad.addColorStop(0, 'rgba(9, 11, 16, 0.92)');
      grad.addColorStop(0.55, 'rgba(9, 11, 16, 0.72)');
      grad.addColorStop(1, 'rgba(9, 11, 16, 0.88)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
    }
  } else {
    // Subtle architectural ambient glow
    const radGrad = ctx.createRadialGradient(
      width * 0.75,
      height * 0.35,
      30,
      width * 0.75,
      height * 0.35,
      width * 0.65
    );
    radGrad.addColorStop(0, `${scene.accentHex}24`);
    radGrad.addColorStop(1, 'rgba(9, 11, 16, 0)');
    ctx.fillStyle = radGrad;
    ctx.fillRect(0, 0, width, height);
  }

  // Subtle architectural grid lines
  ctx.save();
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.035)';
  ctx.lineWidth = 1;
  for (let gx = 96; gx < width; gx += 160) {
    ctx.beginPath();
    ctx.moveTo(gx, 0);
    ctx.lineTo(gx, height);
    ctx.stroke();
  }
  for (let gy = 80; gy < height; gy += 140) {
    ctx.beginPath();
    ctx.moveTo(0, gy);
    ctx.lineTo(width, gy);
    ctx.stroke();
  }
  ctx.restore();

  // 3. Top Broadcast Header (Brand + Scene Index)
  ctx.save();
  ctx.globalAlpha = 0.92;
  ctx.font = '600 20px "Bricolage Grotesque", sans-serif';
  ctx.fillStyle = '#F8FAFC';
  ctx.fillText('WiWorldWeb', 72, 64);

  ctx.font = '500 14px "JetBrains Mono", monospace';
  ctx.fillStyle = '#94A3B8';
  const chapterLabel = `${scene.number} · ${scene.chapter}`;
  const labelW = ctx.measureText(chapterLabel).width;
  ctx.fillText(chapterLabel, width - 72 - labelW, 62);

  // Subtle hairline under header
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
  ctx.beginPath();
  ctx.moveTo(72, 86);
  ctx.lineTo(width - 72, 86);
  ctx.stroke();
  ctx.restore();

  // 4. Left Column: Kinetic Typography Copy
  ctx.save();
  ctx.globalAlpha = opacity;
  const slideOffset = (1 - enter) * 28;

  // Topic kicker (clean unboxed text)
  ctx.font = '500 16px "DM Sans", sans-serif';
  ctx.fillStyle = scene.accentHex;
  ctx.fillText(`${scene.topic}  ·  ${scene.chapter}`, 72, 168 + slideOffset);

  // Headline
  ctx.font = '700 48px "Bricolage Grotesque", sans-serif';
  ctx.fillStyle = '#F8FAFC';
  const headlineLines = wrapTextLines(ctx, scene.headline, 620, 4);
  headlineLines.forEach((line, idx) => {
    ctx.fillText(line, 72, 228 + slideOffset + idx * 58);
  });

  // Subheadline
  const subStartY = 228 + slideOffset + headlineLines.length * 58 + 26;
  ctx.font = '400 22px "DM Sans", sans-serif';
  ctx.fillStyle = '#CBD5E1';
  const subLines = wrapTextLines(ctx, scene.subheadline, 580, 4);
  subLines.forEach((line, idx) => {
    ctx.fillText(line, 72, subStartY + idx * 32);
  });
  ctx.restore();

  // 5. Right Column: Domain-Specific Motion Graphics Visual
  ctx.save();
  ctx.globalAlpha = opacity;
  const panelX = 740;
  const panelY = 148;
  const panelW = 468;
  const panelH = 380;

  // Clean structural dark glass card
  ctx.fillStyle = 'rgba(18, 20, 28, 0.84)';
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.lineWidth = 1.5;
  drawRoundedRect(ctx, panelX, panelY, panelW, panelH, 16);
  ctx.fill();
  ctx.stroke();

  if (scene.visualMode === 'centralization') {
    drawCentralizationGraphic(ctx, panelX, panelY, panelW, panelH, sceneProgress, globalTime);
  } else if (scene.visualMode === 'moderation') {
    drawModerationGraphic(
      ctx,
      panelX,
      panelY,
      panelW,
      panelH,
      sceneProgress,
      scene.evidenceImages ?? [],
      loadedImages
    );
  } else if (scene.visualMode === 'decentralization') {
    drawDecentralizationGraphic(ctx, panelX, panelY, panelW, panelH, sceneProgress, globalTime);
  } else if (scene.visualMode === 'lgpd') {
    drawLgpdGraphic(ctx, panelX, panelY, panelW, panelH, sceneProgress, globalTime);
  } else if (scene.visualMode === 'realtime') {
    drawRealtimeGraphic(ctx, panelX, panelY, panelW, panelH, sceneProgress, globalTime);
  } else {
    drawCtaGraphic(ctx, panelX, panelY, panelW, panelH, sceneProgress, globalTime);
  }
  ctx.restore();

  // 6. Optional Burned-in Subtitles at Bottom
  if (showSubtitles) {
    ctx.save();
    ctx.globalAlpha = Math.min(1, opacity * 1.1);
    ctx.font = '500 18px "DM Sans", sans-serif';
    const captionLines = wrapTextLines(ctx, scene.narration, 920, 2);
    const boxH = captionLines.length * 28 + 24;
    const boxW = 980;
    const boxX = (width - boxW) * 0.5;
    const boxY = height - boxH - 42;

    ctx.fillStyle = 'rgba(9, 11, 16, 0.88)';
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    drawRoundedRect(ctx, boxX, boxY, boxW, boxH, 10);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#F8FAFC';
    ctx.textAlign = 'center';
    captionLines.forEach((line, i) => {
      ctx.fillText(line, width * 0.5, boxY + 30 + i * 28);
    });
    ctx.restore();
  }

  // 7. Bottom Timeline Progress Hairline
  const overallProgress = totalDuration > 0 ? Math.min(1, globalTime / totalDuration) : 0;
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.fillRect(0, height - 4, width, 4);
  ctx.fillStyle = scene.accentHex;
  ctx.fillRect(0, height - 4, width * overallProgress, 4);
}

function drawCentralizationGraphic(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  progress: number,
  time: number
) {
  const cx = x + w * 0.5;
  const cy = y + h * 0.46;

  ctx.font = '500 13px "JetBrains Mono", monospace';
  ctx.fillStyle = '#94A3B8';
  ctx.fillText('MODELO CENTRALIZADO · PONTO ÚNICO DE FALHA', x + 28, y + 36);

  // Outer blocked contributor nodes
  const outerCount = 6;
  for (let i = 0; i < outerCount; i++) {
    const angle = (i / outerCount) * Math.PI * 2 - Math.PI / 2;
    const r = 115;
    const nx = cx + Math.cos(angle) * r;
    const ny = cy + Math.sin(angle) * r;

    const blocked = i % 2 === 0 && progress > 0.35;
    ctx.strokeStyle = blocked ? 'rgba(239, 68, 68, 0.45)' : 'rgba(245, 158, 11, 0.35)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash(blocked ? [5, 5] : []);
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.lineTo(nx, ny);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = blocked ? '#1F1316' : '#181A22';
    ctx.strokeStyle = blocked ? '#EF4444' : '#F59E0B';
    ctx.beginPath();
    ctx.arc(nx, ny, 16, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    if (blocked) {
      ctx.strokeStyle = '#EF4444';
      ctx.beginPath();
      ctx.moveTo(nx - 5, ny - 5);
      ctx.lineTo(nx + 5, ny + 5);
      ctx.moveTo(nx + 5, ny - 5);
      ctx.lineTo(nx - 5, ny + 5);
      ctx.stroke();
    }
  }

  // Central gatekeeper hub
  const pulse = 1 + Math.sin(time * 4) * 0.05;
  ctx.fillStyle = '#271D12';
  ctx.strokeStyle = '#F59E0B';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.arc(cx, cy, 34 * pulse, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.font = '600 13px "DM Sans", sans-serif';
  ctx.fillStyle = '#FCD34D';
  ctx.textAlign = 'center';
  ctx.fillText('HUB ÚNICO', cx, cy + 5);

  ctx.font = '400 14px "DM Sans", sans-serif';
  ctx.fillStyle = '#CBD5E1';
  ctx.fillText('Decisões concentradas limitam a pluralidade editorial.', cx, y + h - 28);
  ctx.textAlign = 'left';
}

function drawModerationGraphic(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  progress: number,
  evidenceImages: string[],
  loadedImages: Record<string, HTMLImageElement>
) {
  ctx.font = '500 12px "JetBrains Mono", monospace';
  ctx.fillStyle = '#FCA5A5';
  ctx.fillText('DOSSIÊ WAZZIMAGIYGG.COM/AVERDADE · REGISTROS 2025', x + 24, y + 34);

  // Cycling documentary screenshot frame from user evidence
  const imgBoxX = x + 24;
  const imgBoxY = y + 50;
  const imgBoxW = w - 48;
  const imgBoxH = 128;

  ctx.fillStyle = '#0A0D14';
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.45)';
  ctx.lineWidth = 1;
  drawRoundedRect(ctx, imgBoxX, imgBoxY, imgBoxW, imgBoxH, 8);
  ctx.fill();

  const slideCount = Math.max(1, evidenceImages.length);
  const slideIdx = Math.min(slideCount - 1, Math.floor(progress * slideCount));
  const activeSrc = evidenceImages[slideIdx];
  const img = activeSrc ? loadedImages[activeSrc] : undefined;

  if (img && img.complete && img.naturalWidth > 0) {
    ctx.save();
    drawRoundedRect(ctx, imgBoxX, imgBoxY, imgBoxW, imgBoxH, 8);
    ctx.clip();
    const scale = Math.min(imgBoxW / img.naturalWidth, imgBoxH / img.naturalHeight);
    const dw = img.naturalWidth * scale;
    const dh = img.naturalHeight * scale;
    const dx = imgBoxX + (imgBoxW - dw) * 0.5;
    const dy = imgBoxY + (imgBoxH - dh) * 0.5;
    ctx.fillStyle = '#E8F5EC';
    ctx.fillRect(imgBoxX, imgBoxY, imgBoxW, imgBoxH);
    ctx.drawImage(img, dx, dy, dw, dh);
    ctx.restore();
  }
  ctx.strokeStyle = 'rgba(239, 68, 68, 0.45)';
  drawRoundedRect(ctx, imgBoxX, imgBoxY, imgBoxW, imgBoxH, 8);
  ctx.stroke();

  const items = [
    {
      label: '25/08/2025 · Chronus cita Johannnnes89, Teles e Edmond Dantès',
      status: 'Associação pública de nome civil em pedido de verificação',
      delay: 0.05,
    },
    {
      label: '28/08/2025 · Edmond Dantès confirma vínculo com contas',
      status: 'Sem consentimento do titular ou revisão externa (LGPD)',
      delay: 0.34,
    },
    {
      label: '23–24/12/2025 · Novo pedido em WP:NI por Chronus',
      status: 'Confirmado por Edmond Dantès em 6h30 · Dossiê A Verdade',
      delay: 0.64,
    },
  ];

  items.forEach((item, idx) => {
    const itemVis = easeOutCubic(Math.max(0, Math.min(1, (progress - item.delay) / 0.16)));
    if (itemVis <= 0) return;

    const rowY = y + 194 + idx * 58;
    ctx.save();
    ctx.globalAlpha *= itemVis;

    const isHighlighted = idx === slideIdx;
    ctx.fillStyle = isHighlighted ? 'rgba(239, 68, 68, 0.12)' : 'rgba(255, 255, 255, 0.03)';
    ctx.strokeStyle = isHighlighted ? 'rgba(239, 68, 68, 0.6)' : 'rgba(255, 255, 255, 0.09)';
    ctx.lineWidth = 1;
    drawRoundedRect(ctx, x + 24, rowY, w - 48, 48, 7);
    ctx.fill();
    ctx.stroke();

    ctx.font = '600 12.5px "DM Sans", sans-serif';
    ctx.fillStyle = '#F8FAFC';
    ctx.fillText(item.label, x + 36, rowY + 20);

    ctx.font = '400 11px "JetBrains Mono", monospace';
    ctx.fillStyle = isHighlighted ? '#FCA5A5' : '#94A3B8';
    ctx.fillText(item.status, x + 36, rowY + 38);

    ctx.restore();
  });
}

function drawDecentralizationGraphic(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  progress: number,
  time: number
) {
  ctx.font = '500 13px "JetBrains Mono", monospace';
  ctx.fillStyle = '#93C5FD';
  ctx.fillText('REDE FEDERADA · WIWORLDWEB MESH', x + 28, y + 36);

  const nodes = [
    { px: 0.26, py: 0.34, label: 'Nó SP' },
    { px: 0.52, py: 0.26, label: 'Nó RJ' },
    { px: 0.78, py: 0.38, label: 'Nó PT' },
    { px: 0.22, py: 0.68, label: 'Nó MG' },
    { px: 0.54, py: 0.62, label: 'Nó Open' },
    { px: 0.80, py: 0.72, label: 'Espelho' },
  ];

  // Draw peer connections
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const a = nodes[i];
      const b = nodes[j];
      const dist = Math.hypot(a.px - b.px, a.py - b.py);
      if (dist < 0.45) {
        const ax = x + a.px * w;
        const ay = y + a.py * h;
        const bx = x + b.px * w;
        const by = y + b.py * h;

        ctx.strokeStyle = 'rgba(59, 130, 246, 0.38)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(bx, by);
        ctx.stroke();

        // Moving sync packet
        const t = (time * 0.6 + i * 0.25) % 1;
        const px = ax + (bx - ax) * t;
        const py = ay + (by - ay) * t;
        ctx.fillStyle = '#60A5FA';
        ctx.beginPath();
        ctx.arc(px, py, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  nodes.forEach((node, idx) => {
    const appear = easeOutCubic(Math.max(0, Math.min(1, (progress - idx * 0.06) / 0.2)));
    const nx = x + node.px * w;
    const ny = y + node.py * h;

    ctx.fillStyle = '#0F172A';
    ctx.strokeStyle = '#3B82F6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(nx, ny, 22 * appear, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    if (appear > 0.5) {
      ctx.font = '600 12px "JetBrains Mono", monospace';
      ctx.fillStyle = '#E2E8F0';
      ctx.textAlign = 'center';
      ctx.fillText(node.label, nx, ny + 4);
      ctx.textAlign = 'left';
    }
  });

  ctx.font = '400 14px "DM Sans", sans-serif';
  ctx.fillStyle = '#CBD5E1';
  ctx.textAlign = 'center';
  ctx.fillText('Zero ponto único de censura ou desligamento.', x + w * 0.5, y + h - 28);
  ctx.textAlign = 'left';
}

function drawLgpdGraphic(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  progress: number,
  _time: number
) {
  ctx.font = '500 13px "JetBrains Mono", monospace';
  ctx.fillStyle = '#6EE7B7';
  ctx.fillText('PRIVACIDADE POR PADRÃO · LGPD (LEI 13.709/18)', x + 28, y + 36);

  const pillars = [
    { title: 'Anonimização de IP', desc: 'Sem exposição de rede doméstica no histórico', code: 'Art. 12' },
    { title: 'Minimização de Dados', desc: 'Apenas o estritamente necessário para autoria', code: 'Art. 6º III' },
    { title: 'Portabilidade e Exclusão', desc: 'Controle direto do titular sobre seus registros', code: 'Art. 18' },
  ];

  pillars.forEach((p, idx) => {
    const appear = easeOutCubic(Math.max(0, Math.min(1, (progress - idx * 0.12) / 0.22)));
    if (appear <= 0) return;

    const cardY = y + 72 + idx * 88;
    ctx.save();
    ctx.globalAlpha *= appear;

    ctx.fillStyle = 'rgba(16, 185, 129, 0.07)';
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.35)';
    ctx.lineWidth = 1.2;
    drawRoundedRect(ctx, x + 28, cardY, w - 56, 72, 10);
    ctx.fill();
    ctx.stroke();

    ctx.font = '600 16px "DM Sans", sans-serif';
    ctx.fillStyle = '#ECFDF5';
    ctx.fillText(p.title, x + 46, cardY + 29);

    ctx.font = '500 13px "JetBrains Mono", monospace';
    ctx.fillStyle = '#34D399';
    const cw = ctx.measureText(p.code).width;
    ctx.fillText(p.code, x + w - 46 - cw, cardY + 29);

    ctx.font = '400 14px "DM Sans", sans-serif';
    ctx.fillStyle = '#A7F3D0';
    ctx.fillText(p.desc, x + 46, cardY + 53);
    ctx.restore();
  });
}

function drawRealtimeGraphic(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  progress: number,
  time: number
) {
  ctx.font = '500 13px "JetBrains Mono", monospace';
  ctx.fillStyle = '#93C5FD';
  ctx.fillText('SINCRONIZAÇÃO CRDT · TEMPO REAL', x + 28, y + 36);

  // Document card mockup inside panel
  ctx.fillStyle = '#0F131C';
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.lineWidth = 1;
  drawRoundedRect(ctx, x + 28, y + 60, w - 56, 260, 10);
  ctx.fill();
  ctx.stroke();

  const lines = [
    '## Arquitetura Aberta do Conhecimento',
    'Contribuidores editam blocos simultaneamente',
    'sem sobrescrever revisões paralelas.',
    'Cada parágrafo mantém assinatura verificável',
    'e consenso distribuído entre instâncias.',
  ];

  const charsVisible = Math.floor(progress * 190);
  let consumed = 0;

  lines.forEach((line, idx) => {
    const start = consumed;
    consumed += line.length;
    const shownCount = Math.max(0, Math.min(line.length, charsVisible - start));
    const slice = line.slice(0, shownCount);

    ctx.font = idx === 0 ? '600 16px "Bricolage Grotesque", sans-serif' : '400 14px "DM Sans", sans-serif';
    ctx.fillStyle = idx === 0 ? '#F8FAFC' : '#CBD5E1';
    ctx.fillText(slice, x + 46, y + 102 + idx * 36);
  });

  // Two animated live collaborator cursors
  const cursor1X = x + 130 + Math.sin(time * 1.8) * 65;
  const cursor1Y = y + 138;
  drawLiveCursor(ctx, cursor1X, cursor1Y, '#3B82F6', 'Ana (Recife)');

  const cursor2X = x + 240 + Math.cos(time * 1.4) * 70;
  const cursor2Y = y + 212;
  drawLiveCursor(ctx, cursor2X, cursor2Y, '#10B981', 'Lucas (Porto)');

  ctx.font = '400 14px "DM Sans", sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.fillText('Mesclagem instantânea · Zero bloqueios de página', x + 28, y + h - 24);
}

function drawLiveCursor(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  color: string,
  name: string
) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.fillRect(x, y - 14, 2, 20);

  ctx.font = '500 11px "DM Sans", sans-serif';
  const tw = ctx.measureText(name).width;
  drawRoundedRect(ctx, x, y - 34, tw + 14, 20, 4);
  ctx.fill();

  ctx.fillStyle = '#FFFFFF';
  ctx.fillText(name, x + 7, y - 20);
  ctx.restore();
}

function drawCtaGraphic(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  progress: number,
  _time: number
) {
  const cx = x + w * 0.5;
  ctx.font = '500 13px "JetBrains Mono", monospace';
  ctx.fillStyle = '#93C5FD';
  ctx.fillText('REPOSITÓRIO OFICIAL · CÓDIGO ABERTO', x + 28, y + 36);

  ctx.textAlign = 'center';
  ctx.font = '700 36px "Bricolage Grotesque", sans-serif';
  ctx.fillStyle = '#F8FAFC';
  ctx.fillText('WiWorldWeb', cx, y + 132);

  ctx.font = '400 16px "DM Sans", sans-serif';
  ctx.fillStyle = '#CBD5E1';
  ctx.fillText('Descentralização · Privacidade LGPD · Tempo Real', cx, y + 172);

  // GitHub link box
  const scale = 0.94 + easeOutCubic(progress) * 0.06;
  ctx.save();
  ctx.translate(cx, y + 250);
  ctx.scale(scale, scale);

  ctx.fillStyle = '#2563EB';
  drawRoundedRect(ctx, -190, -28, 380, 56, 10);
  ctx.fill();

  ctx.font = '500 15px "JetBrains Mono", monospace';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('github.com/WazzimaGiygg/Wiki-alternative', 0, 6);
  ctx.restore();

  ctx.font = '400 13px "DM Sans", sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.fillText('Junte-se à construção de uma enciclopédia verdadeiramente livre.', cx, y + h - 32);
  ctx.textAlign = 'left';
}
