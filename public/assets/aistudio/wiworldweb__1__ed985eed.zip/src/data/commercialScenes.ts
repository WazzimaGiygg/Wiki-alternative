import decentralizedImg from '../assets/images/wiworld_decentralized_network_1794754775241.jpg';
import lgpdImg from '../assets/images/wiworld_lgpd_privacy_1794754776155.jpg';
import realtimeImg from '../assets/images/wiworld_realtime_collab_1794754777290.jpg';

export type SceneVisualMode =
  | 'centralization'
  | 'moderation'
  | 'decentralization'
  | 'lgpd'
  | 'realtime'
  | 'cta';

export interface CommercialScene {
  id: string;
  number: string;
  chapter: string;
  topic: string;
  visualMode: SceneVisualMode;
  durationSec: number;
  headline: string;
  subheadline: string;
  narration: string;
  accentHex: string;
  imageSrc?: string;
  evidenceImages?: string[];
}

export const DEFAULT_COMMERCIAL_SCENES: CommercialScene[] = [
  {
    id: 'scene-centralization',
    number: '01',
    chapter: 'O Gargalo Centralizado',
    topic: 'Diagnóstico',
    visualMode: 'centralization',
    durationSec: 9,
    headline: 'O conhecimento livre não pode depender de um único ponto de controle.',
    subheadline:
      'Enciclopédias tradicionais concentram poder editorial, verificações de conta e bloqueios em estruturas fechadas.',
    narration:
      'Quando o conhecimento público fica preso em servidores centralizados e decisões unilaterais, a colaboração perde sua liberdade original.',
    accentHex: '#F59E0B',
  },
  {
    id: 'scene-moderation',
    number: '02',
    chapter: 'Dossiê: Verificação e Abusos',
    topic: 'Chronus · Edmond Dantès · Teles',
    visualMode: 'moderation',
    durationSec: 15,
    headline: 'Exposição de nome civil e verificações coordenadas em registros públicos.',
    subheadline:
      'Capturas de 2025 documentam pedidos de Chronus, Johannnnes89, Teles e confirmações de Edmond Dantès vinculando identidades civis em páginas abertas.',
    narration:
      'Em registros de agosto e dezembro de 2025, pedidos conduzidos por Chronus, Johannnnes89 e Teles, com confirmações de Edmond Dantès, associam publicamente nomes civis em páginas de verificação. O dossiê wazzimagiygg.com/averdade aponta esses casos como grave violação de privacidade e abuso administrativo.',
    accentHex: '#EF4444',
    evidenceImages: [
      '/assets/aistudio/image_38d9f24c.png',
      '/assets/aistudio/image_f27bbf8d.png',
      '/assets/aistudio/image_d1a21d05.png',
    ],
  },
  {
    id: 'scene-decentralization',
    number: '03',
    chapter: 'Arquitetura Descentralizada',
    topic: 'Soberania da Rede',
    visualMode: 'decentralization',
    durationSec: 11,
    headline: 'WiWorldWeb distribui o saber em nós independentes e auditáveis.',
    subheadline:
      'Sem painel secreto de bloqueios globais, sem censura unilateral e com código aberto para qualquer comunidade hospedar.',
    narration:
      'O projeto WiWorldWeb rompe com o monopólio de administradores e verificadores centrais. Cada nó preserva o histórico íntegro com autonomia real.',
    accentHex: '#3B82F6',
    imageSrc: decentralizedImg,
  },
  {
    id: 'scene-lgpd',
    number: '04',
    chapter: 'Privacidade e LGPD Nativa',
    topic: 'Lei nº 13.709/2018',
    visualMode: 'lgpd',
    durationSec: 12,
    headline: 'Nenhum verificador deveria expor dados civis ou IPs sem base legal.',
    subheadline:
      'Conformidade rigorosa com a LGPD: zero exposição pública de identidade civil, minimização de registros e direito de eliminação.',
    narration:
      'Enquanto disputas na Wikipédia lusófona expõem nomes civis e perfis em logs abertos, o WiWorldWeb aplica a LGPD desde o núcleo: proteção estrita de dados pessoais e transparência ao titular.',
    accentHex: '#10B981',
    imageSrc: lgpdImg,
  },
  {
    id: 'scene-realtime',
    number: '05',
    chapter: 'Colaboração em Tempo Real',
    topic: 'Edição Simultânea',
    visualMode: 'realtime',
    durationSec: 10,
    headline: 'Escreva junto em tempo real, sem guerras de edição ou bloqueios.',
    subheadline:
      'Sincronização instantânea entre autores, histórico criptográfico limpo e fluxo contínuo de revisão coletiva.',
    narration:
      'Com edição simultânea em tempo real, pesquisadores e autores constroem verbetes lado a lado, com mesclagem automática e sem travamentos arbitrários.',
    accentHex: '#3B82F6',
    imageSrc: realtimeImg,
  },
  {
    id: 'scene-cta',
    number: '06',
    chapter: 'Dossiê e Código Aberto',
    topic: 'WiWorldWeb · A Verdade',
    visualMode: 'cta',
    durationSec: 9,
    headline: 'Leia o dossiê completo e participe da alternativa livre no GitHub.',
    subheadline:
      'Acesse wazzimagiygg.com/averdade e github.com/WazzimaGiygg/Wiki-alternative para auditar os registros e contribuir.',
    narration:
      'Confira os documentos em wazzimagiygg.com/averdade, audite o código no GitHub e ajude a construir uma enciclopédia descentralizada, colaborativa e fiel à LGPD.',
    accentHex: '#3B82F6',
  },
];

export function formatTimecode(seconds: number): string {
  const safe = Math.max(0, Math.floor(seconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}
